package lesson03.pkg1;

public class ClassUsingDefault {
    
    public static void main(String[] args) {
        DefaultClass x = new DefaultClass();
    }    
}
