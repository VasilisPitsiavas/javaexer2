package lesson03.pkg1;

class DefaultClass {
    
}
