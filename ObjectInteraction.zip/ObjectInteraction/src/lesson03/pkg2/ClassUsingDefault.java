package lesson03.pkg2;

public class ClassUsingDefault {
    
    public static void main(String[] args) {      
        //DefaultClass x = new DefaultClass(); // compilation error
    }
} 
