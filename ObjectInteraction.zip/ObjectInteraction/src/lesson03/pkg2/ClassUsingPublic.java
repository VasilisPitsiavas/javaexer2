package lesson03.pkg2;

import lesson03.pkg1.PublicClass;

public class ClassUsingPublic {
    
    public static void main(String[] args) {      
        PublicClass x = new PublicClass();        
    }
} 
